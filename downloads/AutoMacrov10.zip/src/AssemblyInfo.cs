﻿using System.Reflection;
[assembly: AssemblyTitle("오토 매크로")]
[assembly: AssemblyDescription("오토 매크로 · 마우스·키보드 매크로")]
[assembly: AssemblyCompany("glasscola")]
[assembly: AssemblyProduct("오토 매크로")]
[assembly: AssemblyVersion("10.0.0.0")]
[assembly: AssemblyFileVersion("10.0.0.0")]
